package com.example.daplu.practice;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
    EditText name, login_email, login_pwd, login_pwd2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.signup);

        name = findViewById(R.id.name);
        login_email = findViewById(R.id.login_email);
        login_pwd = findViewById(R.id.login_pwd);
        login_pwd2 = findViewById(R.id.login_pwd2);

        Button btn_signin = findViewById(R.id.btn_signin);


        btn_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, SigninActivity.class));
            }
        });

    }

    public void Onsignup(View view) {
        String str_name = name.getText().toString();
        String str_login_email = login_email.getText().toString();
        String str_login_pwd = login_pwd.getText().toString();
        String str_login_pwd2 = login_pwd2.getText().toString();

        String type = "register";
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(type, str_name, str_login_pwd, str_login_email);
        startActivity(new Intent(MainActivity.this, SigninActivity.class));

    }
}

