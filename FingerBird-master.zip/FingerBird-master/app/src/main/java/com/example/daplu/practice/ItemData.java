package com.example.daplu.practice;

public class ItemData {
    String subtitle;
    String info;

    public ItemData(String subtitle, String info) {

        this.subtitle = subtitle;
        this.info = info;
    }
}